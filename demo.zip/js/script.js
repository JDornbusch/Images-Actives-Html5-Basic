$(document).ready(function() {
	$("#image_active").imagesActivesBasic({
		optionsFile : "options.xml"
	});
});
